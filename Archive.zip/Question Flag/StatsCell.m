//
//  StatsCell.m
//  Question Flag
//
//  Created by iD Student on 7/18/14.
//  Copyright (c) 2014 SkylerArnold. All rights reserved.
//

#import "StatsCell.h"

@implementation StatsCell

//- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
//{
//    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
//    if (self) {
//
//    }
//    return self;
//}

- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
